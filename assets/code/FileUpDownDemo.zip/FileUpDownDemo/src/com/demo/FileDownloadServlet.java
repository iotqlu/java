package com.demo;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/FileDownloadServlet")
public class FileDownloadServlet extends HttpServlet{
    public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException{
        String num = request.getParameter("num");
        
        InputStream is = new FileInputStream("c:/"+num+".jpg");

        response.setContentType("image/jpeg");
        response.setContentLength(is.available());

        OutputStream os = response.getOutputStream();
        byte[] buf = new byte[8192];
        int length;
        while((length=is.read(buf))!=-1){
            os.write(buf,0,length);
        }
        os.close();
    }
}