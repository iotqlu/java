package com.demo;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/FileUploadServlet")
@MultipartConfig
public class FileUploadServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        String num = request.getParameter("num");
        Part photo = request.getPart("photo");

        String filename = num+".jpg";
        String rootpath = "c:/";

        InputStream is = photo.getInputStream();
        OutputStream os = new FileOutputStream(rootpath+filename);

        byte[] buf = new byte[8192];
        int length;
        while((length=is.read(buf))!=-1){
            os.write(buf, 0, length);
        }
        os.flush();
        os.close();

        response.getWriter().println("file upload success!");
    }
}